/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grafos;




/**
 *
 * @author catalina
 */
public class Functions {
    
    App app =  App.getInstance();
    
    public void showGraph(){
//        Graph graph = new SingleGraph("Grafo"); 
        
    }
    
}
