/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Estructuras;



/**
 *@Nombre: Grafo
 * @author Catalina Matheus 
 * Descripcion: clase grafo con sus getters and setters
 * @version: 15/10/2023
 * 
 */
public class Grafo {
    
    private ListUsers users; 

    public Grafo() {
        this.users = new ListUsers(); 
    }
    
    
    /**
     * @Descripcion: método que vacía el grafo 
     * @author: Catalina Matheus 
     * @version: 16/10/2023
     */
    public void emptyGraph(){
        this.users.setpFirst(null);
        this.users.setpLast(null);
        this.users.setSize(0);
    }
    
    
    /**
     * @Descripcion: función que indica si el grafo está vacío 
     * @author: Catalina Matheus 
     * @version: 16/10/2023
     * @return 
     */
    
    public boolean isGraphEmpty(){
        return this.users.getpFirst() == null; 
    }
   
    /**
     * @return the users
     */
    public ListUsers getUsers() {
        return users;
    }

    /**
     * @param users the users to set
     */
    public void setUsers(ListUsers users) {
        this.users = users;
    }
    
    
    
}
