/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Estructuras;

/**
 *@Descripcion: clase ListRelaciones
 * @author Juan Martin
 * @version: 16/10/2023
 */
public class ListRelaciones {
    private NodeRelaciones pFirst;
    private NodeRelaciones pLast;
    private int size;
    
    /**
 *@Descripcion: Constructor ListRelaciones
 * @author Juan Martin
 * @version: 16/10/2023
 */
    public ListRelaciones(){
        pFirst = null;
        pLast = null;
        size = 0;
    }
    
    
    /**
 *@Descripcion: Funciones ListRelaciones
 * @author Juan Martin
 * @version: 16/10/2023
 */
    public boolean isEmpty(){
        return this.pFirst == null;
    }
    
    public void appendLast(String relaciones){
    NodeRelaciones node = new NodeRelaciones(relaciones);
        if(isEmpty()){
            this.pFirst = node;
            this.pLast = node;
//            pFirst.setpNext(this.pLast);
//            pLast.setpNext(null);  
            this.size ++;
        }
        else{
            pLast.setpNext(node);
            pLast = node;
            this.size ++;
        }
   }
    
    public void print() {
        String mostrar = "";
        
        if (isEmpty()) {
            System.out.println("Vacia!");
        } else {
            NodeRelaciones aux = pFirst;
            
            while (aux != null) {
                mostrar += aux.getRelaciones();
                aux = aux.getpNext();
            }
            System.out.println(mostrar);
        }
    }

    
    /**
 *@Descripcion: ListRelaciones Getters y setters
 * @author Juan Martin
 * @version: 16/10/2023
 */
    public NodeRelaciones getpFirst() {
        return pFirst;
    }

    public void setpFirst(NodeRelaciones pFirst) {
        this.pFirst = pFirst;
    }

    public NodeRelaciones getpLast() {
        return pLast;
    }

    public void setpLast(NodeRelaciones pLast) {
        this.pLast = pLast;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }
    
    
    
}
