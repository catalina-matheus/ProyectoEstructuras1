/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grafos;

import Estructuras.Grafo;
import Estructuras.Node;
import Estructuras.NodeRelaciones;
import Estructuras.NodeUser;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JOptionPane;
//import org.graphstream.graph.Graph;
//import org.graphstream.graph.implementations.SingleGraph;
//import org.graphstream.ui.view.Viewer;

/**
 * @Nombre: App
 * @Descripcion: clase app que tiene diseño singleton para solo crear 1
 * instancia de la clase app
 * @author Catalina
 * @version 14/10/2023
 */
public class App {

    private Grafo graph;

    private static App app;

    /**
     * @Descripcion: constructor de la clase App (se crea la instancia de la
     * clase Grafo)
     * @author: Catalina Matheus
     * @version: 15/10/2023
     */
    private App() {
        this.graph = new Grafo();
    }

    /**
     * @Nombre: getInstance
     * @Descripcion: retorna la unica instancia de app que hay y si no existe la
     * crea
     * @author: Catalina Matheus
     * @version 14/10/2023
     * @return: app
     */
    public static synchronized App getInstance() {
        if (getApp() == null) {
            setApp(new App());
        }
        return getApp();
    }
    
    /**
     * @Descripcion: metodo que verifica si el archivo dado es un txt con el path que se pase por parametro
     * @param path
     * @author: Reinaldo Reyes
     * @version: 16/10/2023
     */
    public boolean validTxt(String nombreArchivo) {
        if (nombreArchivo.toLowerCase().endsWith(".txt")) {
            return true;
        } else {
            return false;
        }
    }
    
    /**
     * @Descripcion: metodo que verifica si el txt dado cumple con la estructura 
     * @param path
     * @return
     * @throws FileNotFoundException
     * @throws IOException 
     * @author: Catalina Matheus 
     * @version: 16/10/2023
     */
    
    public boolean VerifyArchive(String path) throws FileNotFoundException, IOException{
        String line; 
        boolean contieneUsuarios = false; 
        boolean contieneRelaciones = false; 
        boolean contieneIlegal = true; // para cualquier linea que no tenga "usuarios, relaciones o un "@"
        try(BufferedReader br = new BufferedReader(new FileReader(path))){
            while((line=br.readLine())!= null){
                if(line.contains("usuarios")){
                    contieneUsuarios = true; 
                }if(line.contains("relaciones")){
                    contieneRelaciones = true; 
                }if(!contieneUsuarios && !contieneRelaciones && !line.contains("@")){
                    contieneIlegal = false; 
                }
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error! El txt que montó no tiene la estructura permitida."); 
        }return contieneUsuarios && contieneRelaciones && contieneIlegal; 
            
    }

    /**
     * @Descripcion: metodo que lee el txt con el path que se pase por parametro
     * @param path
     * @author: Catalina Matheus
     * @version: 15/10/2023
     */
    // falta validar el txt!!
    // y vaciar cuando se quiera colocar otro txt!
    public void leerTxt(String path) throws IOException {
        String relacionesString = "";
        if(!this.graph.isGraphEmpty()){// vaciamos primero el grafo para meter la nueva información 
            this.getGraph().emptyGraph();
        }
        if (validTxt(path) && this.VerifyArchive(path)) {
            try {
                FileReader fr = new FileReader(path);
                BufferedReader br = new BufferedReader(fr);
                String line;
                while ((line = br.readLine()) != null) {
                    if (line.startsWith("@")) {
                        if (line.contains(",")) {
                            line.replace(" ", "");
                            relacionesString += line + "\n";
                        } else {
                            getGraph().getUsers().appendLast(line);
                        }
                    }
                }
                System.out.println("FLAGGGG 1");

                if (!relacionesString.equals("")) {
                    System.out.println("FLAGGGG 2");
                    String[] lines = relacionesString.split("\n");
                    for (int i = 0; i < lines.length; i++) {
                        String[] lectura = lines[i].split(",");
                        this.insertRelation(lectura[0], lectura[1]);
                    }
                }
                JOptionPane.showMessageDialog(null, "Se logró leer el txt con éxito!");
                this.printGraph();

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error! No se logró leer el txt.");
            }
        }
        else if(!validTxt(path)){
        JOptionPane.showMessageDialog(null, "Error! El archivo dado no es un .txt");
        }else if(!this.VerifyArchive(path)){
            JOptionPane.showMessageDialog(null, "Error! El archivo que colocó no tiene el formato permitido."); 
        }
    }

    /**
     * @Descripcion: método que inserta en la lista "Relaciones" del nodo origen
     * el string destino
     * @param origen
     * @param destino
     * @author: Catalina Matheus
     * @version: 15/10/2023
     */
    public void insertRelation(String origen, String destino) {
        NodeUser aux = getGraph().getUsers().getpFirst();
        while (aux != null) {
            if (aux.getUsername().equals(origen)) {
                aux.getRelaciones().appendLast(destino);
                break;
            }
            aux = aux.getpNext();
        }

    }

    /**
     * @Descripcion: metodo que imprime lo que se encuentra en la estructura
     * grafo (para revisar que la información se este guardando correctamente)
     * @author: Catalina Matheus
     * @version: 15/10/2023
     */
    public void printGraph() {
        String usernames = "";
        String relaciones = "";
        NodeUser aux = getGraph().getUsers().getpFirst();
        while (aux != null) {
            usernames += aux.getUsername() + "->";
            if (!aux.getRelaciones().isEmpty()) {
                relaciones += "Relaciones de: " + aux.getUsername() + "\n";
                NodeRelaciones aux2 = aux.getRelaciones().getpFirst();
                while (aux2 != null) {
                    relaciones += aux2.getRelaciones() + "->";
                    aux2 = aux2.getpNext();
                }
                relaciones += "//\n";

            }
            aux = aux.getpNext();
        }
        usernames += "//";
        System.out.println("USUARIOS: ");
        System.out.println(usernames);
        System.out.println("RELACIONES: ");
        System.out.println(relaciones);
    }
    
    
//    public void eliminateUsername(String username){
//        if(!this.graph.isGraphEmpty()){
//            NodeUserName()
//        }
//        
//    }
//    
    public void mostrarGrafo(){
//        Graph g = new SingleGraph("Grafo");
        
    }

    /**
     * @return the graph
     */
    public Grafo getGraph() {
        return graph;
    }

    /**
     * @param graph the graph to set
     */
    public void setGraph(Grafo graph) {
        this.graph = graph;
    }

    /**
     * @return the app
     */
    public static App getApp() {
        return app;
    }

    /**
     * @param aApp the app to set
     */
    public static void setApp(App aApp) {
        app = aApp;
    }
    
    
    

}
