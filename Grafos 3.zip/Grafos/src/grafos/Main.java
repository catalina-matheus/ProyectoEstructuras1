/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grafos;

import Interfaces.MainInterface;

/**
 *
 * @author reina
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         App app =  App.getInstance();
         MainInterface mI = new MainInterface(); 
         mI.setVisible(true);
         
         
//         app.leerTxt("src//Txt//Usuarios.txt");
//         app.printGraph(); 

         
    }
    
}
