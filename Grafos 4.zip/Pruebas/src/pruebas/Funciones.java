package pruebas;

import javax.swing.JOptionPane;



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author reina
 */
public class Funciones {
    
    
    public int NumtoString(){
        int y = 0;
        String x;
        x = JOptionPane.showInputDialog("Coloca un numero: ");
        boolean Valido = true;
        while(Valido){
            try {
                y = Integer.parseInt(x);
                Valido = false;
                
            } catch (Exception e) {
                System.out.println("No se coloco un numero, intente otra vez");
                break;
            }

        
        
        }
    return y;
    }
}


