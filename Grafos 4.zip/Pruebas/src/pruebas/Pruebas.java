/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pruebas;

import javax.swing.JOptionPane;

/**
 *
 * @author reina
 */
public class Pruebas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Lista_Circular myList = new Lista_Circular<Integer>();
        myList.AddBeginningCL(5);
        myList.AddBeginningCL(4);
        myList.AddEndCL(7);
        myList.AddBeginningCL(3);
        myList.AddBeginningCL(2);
        myList.AddBeginningCL(1);
        myList.AddPosCL(9, 1);
        myList.EliminateEndCL();
        myList.EliminateBeginningCL();
        myList.EliminatePosCL(9);
        myList.PrintC();
 
        
        
        
    }

    

}
