/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grafos;

import Estructuras.Grafo;
import Estructuras.NodeRelaciones;
import Estructuras.NodeUser;
import Estructuras.Stack;
import org.graphstream.graph.Graph;
import org.graphstream.graph.implementations.SingleGraph;
import org.graphstream.ui.view.Viewer;

/**
 * @Descripcion: clase functions donde esta la funcion para mostrar el grafo
 * @author Catalina Matheus
 * @version: 22/10/2023
 */
public class Functions {

    App app = App.getInstance();

    /**
     * @Descripcion: método que muestra el grafo
     * @author: Catalina Matheus
     * @version: 22/10/2023
     */
    public void showGraph() {
        Graph g = new SingleGraph("Grafo");
        // agregamos primero los nodos
        NodeUser aux = app.getGraph().getUsers().getpFirst();

        while (aux != null) {
            g.addNode(aux.getUsername().replace(" ", "")).setAttribute("ui.label", aux.getUsername().replace(" ", ""));

//            NodeRelaciones aux2 = aux.getRelaciones().getpFirst();
            aux = aux.getpNext();
        }

        // ahora agregamos las relaciones: 
        NodeUser auxOrigen = app.getGraph().getUsers().getpFirst();
        while (auxOrigen != null) {
            NodeRelaciones auxRelacion = auxOrigen.getRelaciones().getpFirst();

            while (auxRelacion != null) {
                g.addEdge(auxOrigen.getUsername().replace(" ", "") + auxRelacion.getRelaciones().replace(" ", ""), auxOrigen.getUsername().replace(" ", ""), auxRelacion.getRelaciones().replace(" ", ""), true);
                auxRelacion = auxRelacion.getpNext();
            }
            auxOrigen = auxOrigen.getpNext();
        }
        // falggggg
        g.setAttribute("ui.antialias");
        g.setAttribute("ui.stylesheet", "node{\n" + "size: 100px, 30px;\n fill-color: #add8e6;\n } edge{\n text-background-mode: plain; \n}");
        System.setProperty("org.graphstream.ui", "swing");

        Viewer viewer = g.display();
        viewer.setCloseFramePolicy(Viewer.CloseFramePolicy.HIDE_ONLY);

    }

    /**
     * @Descripcion: metodo que realiza la busqueda en profundidad
     * @param graph 
     * @author: Catalina Matheus 
     * @version:24/10/2023
     */
    public void DFS(Grafo graph) {

        // creamos arreglo de usuarios: 
        String[] usernameArray = new String[graph.getUsers().getSize()];
        NodeUser aux = graph.getUsers().getpFirst();
        for (int i = 0; i < graph.getUsers().getSize(); i++) {
            usernameArray[i] = aux.getUsername();
            aux = aux.getpNext();
        }

        // creamos arreglo de booleanos (todo empieza en false)
        boolean[] visited = new boolean[graph.getUsers().getSize()];

        Stack pila = new Stack(); // donde voy a poner los usuarios cuando ya no hay ningun lugar mas para recorrer
        Stack pilaVisitados = new Stack(); // para ir metiendo los nodos mientras los visito 

        //empezamos con el primero en la lista: 
        String userToCheck = graph.getUsers().getpFirst().getUsername();
//        NodeUser nodeUserToCheck = graph.getUsers().getpFirst(); 
        visited[0] = true;
        pilaVisitados.push(userToCheck);
        System.out.println("EMPEZAMOS A VISITAR!!!!!");
        System.out.println("VISITADO: " + usernameArray[0]);
        while (!this.done(visited)) {
            String userPila = (String) pilaVisitados.getpCima().getData();
            NodeUser nodeUserToCheck = this.getNode(userPila, graph);
            boolean encontrado = false;
            if (!nodeUserToCheck.getRelaciones().isEmpty()) {
//                boolean encontrado = false;
                NodeRelaciones aux1 = nodeUserToCheck.getRelaciones().getpFirst();
                for (int i = 0; i < nodeUserToCheck.getRelaciones().getSize(); i++) {
                    if (!this.wasVisited(usernameArray, visited, aux1.getRelaciones())) {
                        encontrado = true;
                        this.markVisited(aux1.getRelaciones(), visited, usernameArray);// se marca como visitado
                        pilaVisitados.push(aux1.getRelaciones()); // lo metemos en la pila
                        System.out.println("VISITADO: " + pilaVisitados.getpCima().getData());
                        break;
                    }
                    aux1 = aux1.getpNext();
//                    System.out.println("EL VALOR DE ENCONTRADO: " + encontrado);
                }
//                System.out.println("EL VALOR DE ENCONTRADO: " + encontrado);
//                if(!encontrado){
//                    System.out.println("FLAGGGG");
//                    // quiere decir que ya se visitaron todos los nodos entonces hay que desapilar de la pila de desapilados y apilar en la otra pila 
//                    pilaVisitados.pop();
//                    pila.push(nodeUserToCheck);
//                }

//                while(!encontrado){
//                    if (!this.wasVisited(usernameArray, visited, aux1.getRelaciones())) {
//                        encontrado = true; 
//                        this.markVisited(aux1.getRelaciones(), visited, usernameArray);// se marca como visitado
//                        pilaVisitados.push(aux1.getRelaciones()); // lo metemos en la pila
//                        break; 
//                    }
//                    aux1 = aux1.getpNext(); 
//                    
//                }
            } System.out.println("EL VALOR DE ENCONTRADO: " + encontrado);
            if(!encontrado){
                    System.out.println("FLAGGGG");
                    // quiere decir que ya se visitaron todos los nodos entonces hay que desapilar de la pila de desapilados y apilar en la otra pila 
                    pilaVisitados.pop();
                    pila.push(nodeUserToCheck);
                }

        }

    }

    /**
     * @Descripcion: funcion que revisa si el usuario ya fue visitado o no
     * @param usernameArray
     * @param visited
     * @param username
     * @return
     * @author: Catalina Matheus
     * @version: 24/10/2023
     */
    public boolean wasVisited(String[] usernameArray, boolean[] visited, String username) {
        int contador = 0;
        for (int i = 0; i < usernameArray.length; i++) {
            if (usernameArray[i].replace(" ", "").equals(username.replace(" ", ""))) {
                contador = i;
                break;
            }
        }
        return visited[contador];

    }
    
    /**
     * @Descripcion: revisa si todos los nodos del grafo fueron visitados 
     * @param visited
     * @return 
     * @author: Catalina Matheus 
     * @version: 24/10/2023
     */

    public boolean done(boolean[] visited) {
        boolean result = true;
        for (int i = 0; i < visited.length; i++) {
            result = result & visited[i];

        }
        return result;
    }

    /**
     * @Descripcion: busca el nodo en el grafo dado el usuario 
     * @param username
     * @param graph
     * @return 
     * @author: Catalina Matheus 
     * @version: 24/10/2023
     */
    public NodeUser getNode(String username, Grafo graph) {
        NodeUser nodito = graph.getUsers().getpFirst();
        while (nodito != null) {
            if (nodito.getUsername().replace(" ", "").equals(username.replace(" ", ""))) {
                return nodito;
            }
            nodito = nodito.getpNext();
        }
        return nodito;

    }

    /**
     * @Descripcion: marca el usuario como visitado dado el usuario, el arreglo de booleanos y el arreglo de usuarios
     * @param username
     * @param visited
     * @param usernameArray 
     * @author: Catalina Matheus 
     * @version: 24/10/2023
     */
    
    public void markVisited(String username, boolean[] visited, String[] usernameArray) {
        for (int i = 0; i < usernameArray.length; i++) {
            if (usernameArray[i].replace(" ", "").equals(username.replace(" ", ""))) {
                visited[i] = true;
                break;
            }
        }
    }

}
