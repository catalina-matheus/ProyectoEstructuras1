/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grafos;

import Estructuras.NodeRelaciones;
import Estructuras.NodeUser;
import org.graphstream.graph.Graph;
import org.graphstream.graph.implementations.SingleGraph;
import org.graphstream.ui.view.Viewer;

/**
 *@Descripcion: clase functions donde esta la funcion para mostrar el grafo
 * @author Catalina Matheus
 * @version: 22/10/2023
 */
public class Functions {

    App app = App.getInstance();

    /**
     * @Descripcion: método que muestra el grafo 
     * @author: Catalina Matheus 
     * @version: 22/10/2023
     */
    public void showGraph() {
        Graph g = new SingleGraph("Grafo");
        // agregamos primero los nodos
        NodeUser aux = app.getGraph().getUsers().getpFirst();

        while (aux != null) {
            g.addNode(aux.getUsername().replace(" ", "")).setAttribute("ui.label", aux.getUsername().replace(" ", ""));
     
//            NodeRelaciones aux2 = aux.getRelaciones().getpFirst();
            aux = aux.getpNext(); 
        }
 
        
        // ahora agregamos las relaciones: 
        NodeUser auxOrigen = app.getGraph().getUsers().getpFirst(); 
        while(auxOrigen != null){
            NodeRelaciones auxRelacion = auxOrigen.getRelaciones().getpFirst(); 
            
            while(auxRelacion != null){
                g.addEdge(auxOrigen.getUsername().replace(" ","") + auxRelacion.getRelaciones().replace(" ", ""), auxOrigen.getUsername().replace(" ", ""), auxRelacion.getRelaciones().replace(" ", ""), true); 
                auxRelacion = auxRelacion.getpNext(); 
            }
            auxOrigen = auxOrigen.getpNext(); 
        }
        // falggggg
        g.setAttribute("ui.antialias");
        g.setAttribute("ui.stylesheet", "node{\n" + "size: 100px, 30px;\n fill-color: #add8e6;\n } edge{\n text-background-mode: plain; \n}");
        System.setProperty("org.graphstream.ui", "swing");
        
        Viewer viewer = g.display();
        viewer.setCloseFramePolicy(Viewer.CloseFramePolicy.HIDE_ONLY);

    }

}
