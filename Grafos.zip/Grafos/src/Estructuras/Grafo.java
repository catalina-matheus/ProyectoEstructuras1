/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Estructuras;

import grafos.User;

/**
 *@Nombre: Grafo
 * @author Catalina Matheus 
 * Descripcion: clase grafo con sus getters and setters
 * @version: 15/10/2023
 * 
 */
public class Grafo {
    
    private List<User> listaUsuarios; 

    public Grafo() {
        this.listaUsuarios = new List();
        
    }
    

    /**
     * @return the listaUsuarios
     */
    public List getListaUsuarios() {
        return listaUsuarios;
    }

    /**
     * @param listaUsuarios the listaUsuarios to set
     */
    public void setListaUsuarios(List listaUsuarios) {
        this.listaUsuarios = listaUsuarios;
    }
 
    
    
}
