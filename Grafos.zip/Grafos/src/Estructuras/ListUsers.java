/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Estructuras;

/**
 *@Descripcion: clase ListUsers con sus getters y setters
 * @author Catalina Matheus
 * @version: 15/10/2023
 */
public class ListUsers {
    
    private NodeUser pFirst; 
    private NodeUser pLast; 
    private int size; 

    
/**
 * @Descripcion: constructor de la clase ListUsers
 * @author: Catalina Matheus 
 * @version: 15/10/2023
 */
    public ListUsers() {
        this.pFirst = null; 
        this.pLast = null; 
        this.size = 0; 
        
    }
    
    
/**
 * @Descripcion: funcion que retorna si la lista está vacía
 * @return boolean
 * @author: Catalina Matheus 
 * @version: 15/10/2023
 */
    public boolean isEmpty(){
        return this.pFirst == null; 
    }

/**
 * @Descripcion: método que agrega al final de la lista 
 * @param username 
 * @author: Catalina Matheus
 * @version: 15/10/2023
 */
    
    public void appendLast(String username){
        NodeUser node = new NodeUser(username); 
        if (this.isEmpty()) {
            this.pFirst = node; 
            this.pLast = node; 
            this.size ++; 
        }else{
            NodeUser aux = this.pLast;
            aux.setpNext(node);
            this.pLast = node; 
            this.size ++; 
        }
        
    }

    /**
     * @return the pFirst
     */
    public NodeUser getpFirst() {
        return pFirst;
    }

    /**
     * @param pFirst the pFirst to set
     */
    public void setpFirst(NodeUser pFirst) {
        this.pFirst = pFirst;
    }

    /**
     * @return the pLast
     */
    public NodeUser getpLast() {
        return pLast;
    }

    /**
     * @param pLast the pLast to set
     */
    public void setpLast(NodeUser pLast) {
        this.pLast = pLast;
    }

    /**
     * @return the size
     */
    public int getSize() {
        return size;
    }

    /**
     * @param size the size to set
     */
    public void setSize(int size) {
        this.size = size;
    }
    
    
    
    
}
