/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Estructuras;



/**
 *@Descripcion: clase NodeUser con sus getters y setters
 * @author catalina
 * @version: 15/10/2023
 */
public class NodeUser {
    
   private String username; 
   private NodeUser pNext; 
   private List<String> relaciones; 
   
   
/**
 * @Descripcion: constructor de la clase NodeUser
 * @author: Catalina Matheus
 * @param username 
 * @version: 15/10/2023
 */
    public NodeUser(String username) {
        this.username = username; 
        this.pNext = null; 
        this.relaciones = new List(); 
    }

    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return the pNext
     */
    public NodeUser getpNext() {
        return pNext;
    }

    /**
     * @param pNext the pNext to set
     */
    public void setpNext(NodeUser pNext) {
        this.pNext = pNext;
    }

    /**
     * @return the relaciones
     */
    public List<String> getRelaciones() {
        return relaciones;
    }

    /**
     * @param relaciones the relaciones to set
     */
    public void setRelaciones(List<String> relaciones) {
        this.relaciones = relaciones;
    }
   
   
    
    
}
