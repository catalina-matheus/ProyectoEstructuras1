/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grafos;

import Estructuras.Grafo;
import Estructuras.List;
import Estructuras.Node;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import javax.swing.JOptionPane;

/**
 *@Nombre: App
 * @Descripcion: clase app que tiene diseño singleton para solo crear 1 instancia de la clase app 
 * @author Catalina
 * @version 14/10/2023
 */
public class App {
    
    private Grafo graph; 
    
    private static App app;

    
/**
 * @Descripcion: constructor de la clase App (se crea la instancia de la clase Grafo)
 * @author: Catalina Matheus 
 * @version: 15/10/2023
 */
    private App() {
        this.graph = new Grafo(); 

    }
    
/**
 * @Nombre: getInstance
 * @Descripcion: retorna la unica instancia de app que hay y si no existe la crea 
 * @author: Catalina Matheus
 * @version 14/10/2023
 * @return: app
 */

    public static synchronized App getInstance() {
        if (app == null) {
            app = new App();
        }
        return app;
    }
    
   
/**
 * @Nombre: leerTxt
 * @Descripcion: método que lee el txt
 * @param path 
 * @author: Catalina Matheus 
 * @version 14/10/2023
 */

    
    public void leerTxt(String path){
       List usuariosLista = new List(); 
       List relaciones = new List(); 
       
       String line; 
       String relacionesString = ""; 
       File file = new File(path); 
       try{
           if(!file.exists()){
               file.createNewFile(); 
           }else{
             FileReader fr = new FileReader(file); 
             BufferedReader br = new BufferedReader(fr); 
             while((line = br.readLine())!= null){
                 if(!line.isEmpty()){
                     if(line.startsWith("@")){
                         if (line.contains(",")) {
                             relacionesString+= line+ "\n"; 
                             relaciones.appendLast(line);
                         }else{
                             graph.getListaUsuarios().appendLast(line);
                             usuariosLista.appendLast(line);
                         }
                         
                         
                     }
                     
                 }
                 
             } if(!"".equals(relacionesString)){
                 String lecturaSplit = relacionesString.replace("(?m)^[ \t]*\r?\n", "");
                 String[] lines = lecturaSplit.split("\\n");// en cada indice vamos a tener los dos usauris que tienen la relación
                 for (int i = 0; i < lines.length; i++) {
                     String[] usuarios = lines[i].split(","); // en el indice 0 esta en vertice origen y en el 1 esta el vertice de llegada
                     this.insertRelationship(usuarios[0], usuarios[1]);
               }
             }
             
           }System.out.println("Lista usuarios: ");
           graph.getListaUsuarios().print();
           System.out.println("");
           System.out.println("Lista relaciones");
           relaciones.print(); 
           
       }catch(Exception e){
           JOptionPane.showMessageDialog(null, "No se logró leer el txt"); 
       }
        
    }
    
    /**
     * @Descripcion: método para insertar en la lista de adyacencia de un nodo el vertice con el que es adyacente 
     * @author: Catalina Matheus 
     * @version: 15/10/2023
     * @param origen
     * @param llegada 
     */
    public void insertRelationship(String origen, String llegada){ // este es para crear un nuevo nodo para las adyancencias 
       Node aux = graph.getListaUsuarios().getpFirst(); 
        for (int i = 0; i < graph.getListaUsuarios().getSize(); i++) {
            if (((User)aux.getData()).getUserName().equals(origen)) {
                ((List)((User)aux.getData()).getListaRelaciones()).appendLast(llegada);
            }
            aux = aux.getpNext(); 
            
            
        }
        
    }
    
    public void insertR(String origen, String llegada){// este es para insertar una referencia al nodo de adyancencia 
        
        Node auxLlegada = graph.getListaUsuarios().getpFirst(); 
        for (int i = 0; i < graph.getListaUsuarios().getSize(); i++) {
            if (((User)auxLlegada.getData()).getUserName().equals(llegada)) {
                break; 
                
            }auxLlegada = auxLlegada.getpNext(); 
            
        }
        Node auxPrincipal = graph.getListaUsuarios().getpFirst(); 
        for (int i = 0; i < graph.getListaUsuarios().getSize(); i++) {
            if (((User)auxPrincipal.getData()).getUserName().equals(origen)) {
                
                
            }
                auxPrincipal = auxPrincipal.getpNext(); 
            }
        
        
    }

    /**
     * @Descripcion: método para escribir en el txt lo que este guardado en la estructura grafo
     * @author: Catalina Matheus 
     * @version: 15/10/2023
     */
    public void escribirTxt(){
        String userNamesString =""; 
        String relacionesString = ""; 
        relacionesString +="relaciones"; // para guardar las relaciones
        userNamesString +="usuarios"; // para guardar los usuarios
        if (!graph.getListaUsuarios().isEmpty()) {
            Node aux = graph.getListaUsuarios().getpFirst(); 
            for (int i = 0; i < graph.getListaUsuarios().getSize(); i++) {
               userNamesString += "\n"+((User)aux.getData()).getUserName(); 
               Node aux2 = ((User)aux.getData()).getListaRelaciones().getpFirst(); 
                for (int j = 0; j < ((User)aux.getData()).getListaRelaciones().getSize(); j++) {
                    relacionesString +="\n"+((User)aux.getData()).getUserName()+","+aux2.getData(); 
                    aux2 = aux2.getpNext(); 
                    
                }
                aux = aux.getpNext();     
            }
        //REVISAR!!!!!Lo puse adentro del if para que si no hay nada en el grafo no se dañe el txt que ya tenemos
        try{
            PrintWriter pw = new PrintWriter("src//Txt//Usuarios.txt"); 
            pw.print(userNamesString); 
            pw.print(relacionesString);
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "No se logró escribir en el txt ya que la estructura está vacía");
        }
        }
        
    }

    }


