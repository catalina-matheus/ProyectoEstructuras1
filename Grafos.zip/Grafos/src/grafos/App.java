/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grafos;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import javax.swing.JOptionPane;

/**
 *
 * @author catalina
 * @Descripcion: clase app que tiene diseño singleton
 */
public class App {

    private static App app;

    private App() {

    }

    public static synchronized App getInstance() {
        if (app == null) {
            app = new App();
        }
        return app;
    }

//    public void lecturaTxt(String path) {
//        String lectura_txt = "";
//        File file = new File(path);
//        String line;
//        try {
//            if (!file.exists()) {
//                file.createNewFile(path);
//            } else {
//                FileReader fr = new FileReader(file);
//                BufferedReader br = new BufferedReader(fr);
//                while ((line = br.readLine()) != null) {
//                    if (!line.isEmpty()) {
//                        lectura_txt += line + "\n";
//
//                    }
//
//                }//
//            }
//
//        }catch(Exception e){
//            JOptionPane.showMessageDialog(null, "No se logró leer el txt"); 
//        }
    }


