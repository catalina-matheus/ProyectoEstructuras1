/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grafos;

/**
 *
 * @author catalina
 * @Descripcion: clase app que tiene diseño singleton
 */
public class App {
    private static App app;
    
    private App() {
       
           
    }
    public static synchronized App getInstance(){
        if (app == null){
            app = new App();
        }
        return app; 
    }
    
    
}
