/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grafos;

import Estructuras.List;

/**
 *@Nombre User
 * @Descripcion: clase user que tendrá un string con el nombre del usuario y su lista de adyancencia
 * @author Catalina Matheus 
 * @version 15/10/2023
 */

public class User {
    
    private String userName; 
    private List<String> listaRelaciones; 

    public User(String userName) {
        this.userName = userName;
        this.listaRelaciones = new List(); // donde estaran todos los usuarios con sus relaciones
    }

    /**
     * @return the userName
     */
    public String getUserName() {
        return userName;
    }

    /**
     * @param userName the userName to set
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * @return the listaRelaciones
     */
    public List<String> getListaRelaciones() {
        return listaRelaciones;
    }

    /**
     * @param listaRelaciones the listaRelaciones to set
     */
    public void setListaRelaciones(List<String> listaRelaciones) {
        this.listaRelaciones = listaRelaciones;
    }
    
}
